Original project: https://github.com/benhoyt/inih
Pinned upstream commit: 611ab51f8dd7ec583543815b0de693495045fbf8
The course fixture retains the upstream core and license; main.c, Makefile, Dockerfile and the helper wrapper are course additions.
Upstream file hashes: {"helper.c": "49635826cc1ae71209ba88cdad0640d7d1a079779ee24c521efd1e06f4a60633", "ini.h": "db3995229183d50d42cb675bf048f04525aed857fe3e4e39a54a1d7dd2f0f2e9"}
