# E13 测试项目：固定上游版本与课程适配副本

本包提供三个真实开源 C 项目在固定提交上的源码，以及适配课程 E12 接口的测试副本。每个项目有：

- `upstream-original/`：对应上游提交的原始跟踪文件，可查看原项目源码、许可、构建脚本和测试。
- `repo/`：独立 Git 仓库，含 C0/C1 两个提交；保留上游核心库源码和许可，加入课程的双源码入口、明确 Make 规则与一个新的本地头文件依赖。
- `candidate.Dockerfile`：供现有 DRAFT 回放使用的构建候选。

项目来源和固定提交记录在每个 `repo/UPSTREAM.md`。课程适配副本改变了项目结构，仅用于本课程当前两源码、`main.o`/`helper.o` 的集成接口；它们不是未经修改的上游项目。上游项目自带测试已由教师在固定提交运行通过。

请把 ZIP 解压到本组测试仓库的 `data/` 目录，例如在 Linux 仓库根目录运行：

```bash
python3 -m zipfile -e e13-upstream-student.zip data
git -C data/e13-upstream-student/H1-jsmn/repo log -2 --oneline
```

三个项目分别创建新的请求与 `work/` 证据目录。记录 C0/C1 完整提交号、请求、状态、各阶段日志和产物哈希。按 E13 手册提交检测结果和必要的修复证据。本包不提供预期依赖发现、教师判定脚本或测试结果。
