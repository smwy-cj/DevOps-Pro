#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
export E14_ROOT="$ROOT"
export E14_IMAGE="${E14_IMAGE:-course-e11e12:241880068}"
export E14_UID="$(id -u)"
export E14_GID="$(id -g)"
export E14_DOCKER_GID="$(stat -c '%g' /var/run/docker.sock)"
exec docker compose --env-file "$HERE/.env" \
  -f "$ROOT/labs/e13e14/compose.yaml" \
  -f "$HERE/compose.yaml" \
  -p micro-devops-b06-241880068 "$@"
