"""Generate a local Grafana password without printing it or replacing an existing one."""
import os
from pathlib import Path
import secrets

path = Path(__file__).resolve().with_name('.env')
try:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
except FileExistsError:
    print('Existing monitoring .env preserved')
else:
    with os.fdopen(fd, 'w') as stream:
        stream.write('GRAFANA_ADMIN_PASSWORD=' + secrets.token_urlsafe(24) + '\n')
    print('Created monitoring .env; password not printed')
