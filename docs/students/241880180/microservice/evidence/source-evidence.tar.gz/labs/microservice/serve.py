"""Serve the unchanged E14 handler with concurrent monitoring endpoints."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'labs/e13e14'))
from metrics import ServiceMetrics, pipeline_metrics


def metric_reply(handler, body):
    content = body.encode()
    handler.send_response(200)
    handler.send_header('Content-Type', 'text/plain; version=0.0.4; charset=utf-8')
    handler.send_header('Content-Length', str(len(content)))
    handler.end_headers()
    handler.wfile.write(content)


def make_handler(role):
    if role == 'observer':
        class Observer(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == '/metrics':
                    metric_reply(self, pipeline_metrics(ROOT))
                elif self.path == '/health':
                    body = json.dumps({'status': 'ok', 'role': 'observer'}).encode()
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Content-Length', str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                else:
                    self.send_error(404)
        return Observer
    import service
    service.ROLE = role
    meter = ServiceMetrics(role)
    service.run = meter.observe(service.run)

    class Monitored(service.Handler):
        def do_GET(self):
            if self.path == '/metrics':
                metric_reply(self, meter.render())
            else:
                super().do_GET()
    return Monitored


if __name__ == '__main__':
    ThreadingHTTPServer(('0.0.0.0', 8080), make_handler(os.environ.get('E14_ROLE'))).serve_forever()
