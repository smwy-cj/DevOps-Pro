"""Bounded Prometheus labels for real E14 services and persisted pipeline runs."""
from functools import wraps
import hashlib
import json
import math
from pathlib import Path
import threading
import time
from datetime import datetime, timezone

STATUSES = ('SUCCEEDED', 'FAILED', 'TIMED_OUT')
ROLES = ('draft', 'buildchecker', 'echecker', 'mdfixer')


class ServiceMetrics:
    def __init__(self, role):
        if role not in ROLES:
            raise ValueError('Invalid service role')
        self.role = role
        self.lock = threading.Lock()
        # Preserve the original one-business-request-at-a-time behavior while
        # allowing independent health and metric scrapes during a long build.
        self.execution = threading.Lock()
        self.count = dict.fromkeys(STATUSES, 0)
        self.seconds = dict.fromkeys(STATUSES, 0.0)
        self.running = 0

    def observe(self, function):
        @wraps(function)
        def measured(data):
            with self.execution:
                start = time.monotonic()
                status = 'SUCCEEDED'
                with self.lock:
                    self.running += 1
                try:
                    return function(data)
                except Exception as exc:
                    status = 'TIMED_OUT' if 'TIMED_OUT' in str(exc) else 'FAILED'
                    raise
                finally:
                    elapsed = time.monotonic() - start
                    with self.lock:
                        self.running -= 1
                        self.count[status] += 1
                        self.seconds[status] += elapsed
                    print(json.dumps({
                        'timestamp': datetime.now(timezone.utc).isoformat(),
                        'event': 'service_finished', 'service': self.role,
                        'job_id': data.get('job_id') if isinstance(data, dict) else None,
                        'trace_id': data.get('trace_id') if isinstance(data, dict) else None,
                        'status': status, 'duration_ms': round(elapsed * 1000),
                    }), flush=True)
        return measured

    def render(self):
        rows = [
            '# HELP devops_service_runs_total Completed capability calls, not whole pipeline jobs.',
            '# TYPE devops_service_runs_total counter',
            '# TYPE devops_service_duration_seconds_sum counter',
            '# TYPE devops_service_duration_seconds_count counter',
            '# TYPE devops_service_running gauge',
        ]
        with self.lock:
            for status in STATUSES:
                labels = f'service="{self.role}",status="{status}"'
                rows.extend([
                    f'devops_service_runs_total{{{labels}}} {self.count[status]}',
                    f'devops_service_duration_seconds_count{{{labels}}} {self.count[status]}',
                    f'devops_service_duration_seconds_sum{{{labels}}} {self.seconds[status]}',
                ])
            rows.append(f'devops_service_running{{service="{self.role}"}} {self.running}')
        return '\n'.join(rows) + '\n'


def pipeline_metrics(root):
    """Only count completed jobs whose saved result matches its recorded SHA."""
    root = Path(root).resolve()
    counts = dict.fromkeys(STATUSES, 0)
    durations = dict.fromkeys(STATUSES, 0.0)
    running = errors = 0
    for path in sorted((root / 'work/microservice-observer').glob('*.json')):
        try:
            record = json.loads(path.read_text())
            if record['status'] == 'RUNNING':
                running += 1
                continue
            status = record['status']
            if (status not in STATUSES or record['duration_seconds'] < 0
                    or not math.isfinite(record['duration_seconds'])):
                raise ValueError('Invalid terminal record')
            result = (root / record['result']).resolve()
            allowed = root / 'work/microservice-runs'
            if not result.is_relative_to(allowed) or result.name != 'result.json':
                raise ValueError('Result path outside monitored jobs')
            content = result.read_bytes()
            if hashlib.sha256(content).hexdigest() != record['result_sha256']:
                raise ValueError('Result checksum changed')
            data = json.loads(content)
            if (data['job_id'], data['trace_id'], data['status']) != (
                    record['job_id'], record['trace_id'], record['result_status']):
                raise ValueError('Result identity changed')
            expected = data['status']
            if expected == 'FAILED' and 'TIMED_OUT' in str(data.get('error', '')):
                expected = 'TIMED_OUT'
            if status != expected:
                raise ValueError('Terminal classification changed')
            counts[status] += 1
            durations[status] += record['duration_seconds']
        except (OSError, ValueError, TypeError, KeyError):
            errors += 1
    rows = [
        '# HELP devops_pipeline_jobs_total Whole pipeline terminal results verified against saved result hashes.',
        '# TYPE devops_pipeline_jobs_total counter',
        '# TYPE devops_pipeline_duration_seconds_sum counter',
        '# TYPE devops_pipeline_duration_seconds_count counter',
        '# TYPE devops_pipeline_running gauge',
        '# TYPE devops_observer_record_errors gauge',
    ]
    for status in STATUSES:
        labels = f'status="{status}"'
        rows.extend([
            f'devops_pipeline_jobs_total{{{labels}}} {counts[status]}',
            f'devops_pipeline_duration_seconds_count{{{labels}}} {counts[status]}',
            f'devops_pipeline_duration_seconds_sum{{{labels}}} {durations[status]}',
        ])
    rows.extend([f'devops_pipeline_running {running}', f'devops_observer_record_errors {errors}'])
    return '\n'.join(rows) + '\n'
