B06 实际 DevOps 项目监控扩展

基线：v0.9-rc / e508b35a9bd7a5517a2eaa0e2e11048cd7714aad。
新增目录 labs/microservice；不替换 E13/E14 文件，不移动发布标签。

四个业务服务仍运行原有 E14 Handler 和业务函数。serve.py 包装调用统计，
使用多线程 HTTP 服务使耗时构建期间 /health、/metrics 仍可响应；每个角色
的业务执行继续串行。角色级指标只使用 service/status 有限标签，job_id、
trace_id 只进入结构化日志及结果文件。

完整任务使用 python3 labs/microservice/run.py --request ... --out
work/microservice-runs/<唯一名称>。包装器仍调用原 orchestrate.execute，
不改写 result.json。独立 observer 容器读取 work/microservice-observer 中的
任务观测记录，并校验原结果文件的 SHA-256 和 job/trace 身份后才统计终态。
之前直接使用原 orchestrate.py 完成的任务不会被补算成新监控数据。

终态：原流程 SUCCEEDED 统计成功；FAILED 且错误中包含 TIMED_OUT 统计超时，
其他 FAILED 统计失败。原始 result.json 仍保留它原来的 FAILED 状态。
包装器异常或结果哈希不符使 devops_observer_record_errors 增加，不能当作成功。
如果进程被 kill -9，RUNNING 记录可能残留，需要结合进程和日志核对，不能
自行宣布任务终态。服务调用计数会在容器重建时归零；完整任务计数由磁盘
观测记录恢复。请保留整个 work/microservice-observer 和对应任务目录。

本组项目现有编排对每个阶段发送一次请求；不会重试有副作用的修复操作。
HTTP 调用有原有 720 秒上限，DRAFT 构建有请求内 600 秒上限。
教学样例的三次重试证据应与本组项目的一次调用策略分别报告。

本组 Grafana：服务器 127.0.0.1:13100，Prometheus：127.0.0.1:19190。
教学样例的 13000/19090 不变。所有网页仅监听回环地址，经 SSH 隧道访问。
密码由 init.py 创建到本目录 .env，禁止提交或打包 .env；未包含默认密码。
Grafana 仪表板：B06 实际 DevOps 项目监控。
Prometheus 目标：四个业务角色与 observer，共 5 个目标。

正常任务服务调用预期：draft 1，buildchecker 3，echecker 1，mdfixer 1；
整个五阶段任务成功次数只增加 1。up=1 仅说明监控采集成功，任务成功以
结果及 devops_pipeline_jobs_total 为准。最近 5 分钟没有任务完成时平均
耗时面板可能没有数据，这是 rate 的正常含义。

本扩展没有实现 DRAFT 构建镜像向下游阶段的动态环境交接。现有四个角色
仍共用 course-e11e12 教学运行镜像；报告中须保留该限制。

验证：本地执行监控测试、E14 回归测试和 Compose 合并校验；真实 Linux
Docker 部署、Prometheus 抓取及 Grafana 截图由服务器上运行结果确认。
