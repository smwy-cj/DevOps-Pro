import hashlib
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest import mock
from urllib.request import ProxyHandler, Request, build_opener

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
import metrics
import serve
import run as runner


class MonitoringTests(unittest.TestCase):
    def test_failure_timeout_and_bounded_labels(self):
        meter = metrics.ServiceMetrics('draft')
        for message in ('ordinary error', 'DRAFT_TIMED_OUT'):
            def fail(data):
                raise ValueError(message)
            with self.assertRaises(ValueError):
                meter.observe(fail)({'job_id': 'private-job', 'trace_id': 'private-trace'})
        output = meter.render()
        self.assertIn('status="FAILED"} 1', output)
        self.assertIn('status="TIMED_OUT"} 1', output)
        self.assertNotIn('private-job', output)
        self.assertNotIn('private-trace', output)
        self.assertIn('devops_service_running{service="draft"} 0', output)

    def test_http_health_and_scrape_remain_available_during_business_call(self):
        sys.path.insert(0, str(HERE.parents[0] / 'e13e14'))
        import service
        entered, release = threading.Event(), threading.Event()

        def slow(data):
            entered.set()
            if not release.wait(5):
                raise ValueError('test synchronization timed out')
            return {'status': 'SUCCEEDED'}

        original_run = service.run
        self.addCleanup(setattr, service, 'run', original_run)
        service.run = slow
        handler = serve.make_handler('draft')
        server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        url = 'http://127.0.0.1:' + str(server.server_port)
        urlopen = build_opener(ProxyHandler({})).open
        errors = []

        def submit():
            try:
                req = Request(url + '/v1/run', data=b'{"job_id":"job-one","trace_id":"trace-one"}',
                              headers={'Content-Type': 'application/json'})
                with urlopen(req, timeout=6) as response:
                    self.assertEqual(json.load(response)['status'], 'SUCCEEDED')
            except Exception as exc:
                errors.append(exc)

        client = threading.Thread(target=submit)
        client.start()
        try:
            self.assertTrue(entered.wait(2))
            with urlopen(url + '/metrics', timeout=1) as response:
                self.assertIn('devops_service_running{service="draft"} 1', response.read().decode())
            with urlopen(url + '/health', timeout=1) as response:
                self.assertEqual(json.load(response)['status'], 'ok')
        finally:
            release.set()
            client.join(7)
        self.assertFalse(client.is_alive())
        self.assertEqual(errors, [])
        with urlopen(url + '/metrics', timeout=1) as response:
            self.assertIn('status="SUCCEEDED"} 1', response.read().decode())

    def test_business_execution_stays_serial(self):
        meter = metrics.ServiceMetrics('echecker')
        entered, release, second = threading.Event(), threading.Event(), threading.Event()

        @meter.observe
        def call(data):
            if data['n'] == 1:
                entered.set()
                release.wait(3)
            else:
                second.set()
            return {'status': 'SUCCEEDED'}

        first = threading.Thread(target=call, args=({'n': 1},))
        other = threading.Thread(target=call, args=({'n': 2},))
        first.start()
        self.assertTrue(entered.wait(1))
        other.start()
        try:
            self.assertFalse(second.wait(.05))
        finally:
            release.set()
            first.join(4)
            other.join(4)
        self.assertTrue(second.is_set())
        self.assertIn('status="SUCCEEDED"} 2', meter.render())

    def test_persisted_pipeline_outcomes_and_tampered_result(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve()
            requests = {}

            def original(request, out):
                out.mkdir(parents=True)
                result = {'job_id': 'job-' + request['name'], 'trace_id': 'trace-' + request['name'],
                          'status': request['status'], 'stages': [], 'input_unchanged': True,
                          'error': request.get('error')}
                (out / 'result.json').write_text(json.dumps(result))
                requests[request['name']] = result
                return result

            with mock.patch.object(runner, 'ROOT', root), mock.patch.object(runner.orchestrate, 'execute', original):
                for name, status, error in (
                        ('normal', 'SUCCEEDED', None),
                        ('down', 'FAILED', 'Connection refused'),
                        ('timeout', 'FAILED', 'DRAFT_TIMED_OUT')):
                    result = runner.execute({'name': name, 'status': status, 'error': error},
                                            root / 'work/microservice-runs' / name)
                    self.assertEqual(result['status'], status)
                snapshot = (root / 'work/microservice-observer/normal.json').read_bytes()
                with self.assertRaises(ValueError):
                    runner.execute({}, root / 'work/microservice-runs/normal')
                self.assertEqual(snapshot, (root / 'work/microservice-observer/normal.json').read_bytes())
            text = metrics.pipeline_metrics(root)
            for status in metrics.STATUSES:
                self.assertIn(f'devops_pipeline_jobs_total{{status="{status}"}} 1', text)
            self.assertIn('devops_observer_record_errors 0', text)
            (root / 'work/microservice-runs/normal/result.json').write_text('{}')
            text = metrics.pipeline_metrics(root)
            self.assertIn('devops_pipeline_jobs_total{status="SUCCEEDED"} 0', text)
            self.assertIn('devops_observer_record_errors 1', text)

    def test_incomplete_run_is_observer_error_not_success(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve()
            with mock.patch.object(runner, 'ROOT', root), mock.patch.object(
                    runner.orchestrate, 'execute', side_effect=OSError('unavailable')):
                with self.assertRaises(OSError):
                    runner.execute({}, root / 'work/microservice-runs/broken')
            self.assertIn('devops_observer_record_errors 1', metrics.pipeline_metrics(root))
            self.assertIn('devops_pipeline_jobs_total{status="SUCCEEDED"} 0', metrics.pipeline_metrics(root))


if __name__ == '__main__':
    unittest.main()
