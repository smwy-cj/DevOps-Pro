"""Confirm actual Prometheus scrapes, beyond container health checks."""
import json
import time
from urllib.parse import urlencode
from urllib.request import ProxyHandler, build_opener

opener = build_opener(ProxyHandler({}))
base = 'http://127.0.0.1:19190/api/v1/query?'
last = None
for attempt in range(45):
    try:
        query = 'up{job=~"b06-services|b06-pipeline"}'
        with opener.open(base + urlencode({'query': query}), timeout=3) as response:
            result = json.load(response)
        rows = result['data']['result']
        last = [(x['metric']['instance'], x['value'][1]) for x in rows]
        expected = {'draft:8080', 'buildchecker:8080', 'echecker:8080', 'mdfixer:8080', 'observer:8080'}
        if {x[0] for x in last} == expected and len(last) == 5 and all(x[1] == '1' for x in last):
            for instance, value in sorted(last):
                print(instance, 'up=' + value)
            with opener.open(base + urlencode({'query': 'devops_observer_record_errors'}), timeout=3) as response:
                errors = json.load(response)['data']['result']
            if len(errors) != 1 or errors[0]['value'][1] != '0':
                raise SystemExit('Observer record errors detected: inspect monitoring records')
            print('B06_MONITORING_TARGETS=PASS (5/5 up; observer errors=0)')
            break
    except (OSError, ValueError, KeyError) as exc:
        last = str(exc)
    time.sleep(1)
else:
    raise SystemExit('Monitoring targets not ready: ' + str(last))
