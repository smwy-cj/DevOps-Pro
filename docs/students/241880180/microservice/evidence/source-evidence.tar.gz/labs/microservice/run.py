"""Run the existing real pipeline and record its terminal state for monitoring."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'labs/e13e14'))
import orchestrate


def atomic_save(path, data):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    os.replace(temporary, path)


def execute(request, out):
    out = Path(out).resolve()
    if out.parent != ROOT / 'work/microservice-runs':
        raise ValueError('Output must be a direct child of work/microservice-runs/')
    if out.exists():
        raise ValueError('Preserve existing evidence; choose a fresh output path')
    records = ROOT / 'work/microservice-observer'
    records.mkdir(parents=True, exist_ok=True)
    record_path = records / (out.name + '.json')
    record = {'status': 'RUNNING', 'started_at': datetime.now(timezone.utc).isoformat(),
              'result': (out / 'result.json').relative_to(ROOT).as_posix()}
    with record_path.open('x') as stream:
        json.dump(record, stream)
    start = time.monotonic()
    try:
        result = orchestrate.execute(request, out)
    except Exception as exc:
        # An incomplete run is an observation error, never a manufactured result.
        record.update(status='OBSERVER_ERROR', error=type(exc).__name__ + ': ' + str(exc),
                      duration_seconds=time.monotonic() - start)
        atomic_save(record_path, record)
        raise
    status = result['status']
    if status == 'FAILED' and 'TIMED_OUT' in str(result.get('error', '')):
        status = 'TIMED_OUT'
    record.update(status=status, result_status=result['status'],
                  duration_seconds=time.monotonic() - start,
                  finished_at=datetime.now(timezone.utc).isoformat(),
                  job_id=result['job_id'], trace_id=result['trace_id'],
                  result_sha256=hashlib.sha256((out / 'result.json').read_bytes()).hexdigest())
    atomic_save(record_path, record)
    print(json.dumps({'event': 'pipeline_finished', **record}, ensure_ascii=False), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    result = execute(json.loads(args.request.read_text()), args.out)
    print(json.dumps({'status': result['status'], 'job_id': result['job_id'],
                      'trace_id': result['trace_id'], 'stages': [s['name'] for s in result['stages']],
                      'input_unchanged': result.get('input_unchanged'), 'error': result.get('error')},
                     ensure_ascii=False), flush=True)
    return 0 if result['status'] == 'SUCCEEDED' else 1


if __name__ == '__main__':
    sys.exit(main())
